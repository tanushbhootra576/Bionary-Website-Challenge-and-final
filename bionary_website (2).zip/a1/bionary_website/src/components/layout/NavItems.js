export const navItems = [
  { name: "Home", href: "/"},
  { name: "About", href: "/about" },
  { name: "Team", href: "/team" },
  { name: "Departments", href: "/departments" },
  { name: "Events", href: "/events" },
  { name: "Gallery", href: "/gallery" },
  { name: "Blog", href: "/blog" },
  { name: "Contact", href: "/contact" },
  { name: "Leaderboard", href: "/leaderboard" },
];
